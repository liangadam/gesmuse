
from PyQt5.QtWidgets import QApplication, QMainWindow, QWidget, QPushButton,QDialog
from PyQt5.QtWidgets import QMessageBox, QAction, QToolTip,QLabel
from PyQt5.QtGui import QFont,QPalette, QBrush, QPixmap
from PyQt5.QtWidgets import QHBoxLayout, qApp, QVBoxLayout
from PyQt5.QtCore import QCoreApplication
from PyQt5 import QtCore
import pygame

class StartWindow(QDialog):
    def __init__(self):
        super().__init__()
        self.init_stw()

    def init_stw(self):
        self.resize(1000, 600)
        self.setWindowTitle('录制音频')
        self.btn = QPushButton('返回', self)
        self.btn.setGeometry(50, 50, 100, 50)
        self.btn.clicked.connect(self.slot_btn_function)
        self.btn2 = QPushButton('停止录制', self)
        self.btn2.setGeometry(50, 150, 100, 50)
        self.btn2.clicked.connect(self.slot_btn_function)

        hbox = QHBoxLayout(self)
        lbl = QLabel(self)
        pixmap = QPixmap("图片路径")
        lbl.setPixmap(pixmap)
        lbl.setScaledContents(True)
        hbox.addWidget(lbl)
        self.setLayout(hbox)

        #
        # '''sound = pygame.mixer.Sound(r"此处为音频文件路径.wav")
        # sound.set_volume(1)
        # sound.play()'''

        # self.setWindowFlag(QtCore.Qt.FramelessWindowHint)
        # self.showFullScreen()

        def slot_btn_function(self):
            self.hide()

            self.f = _Begin()

            self.f.show()


